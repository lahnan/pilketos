<?php
class Pdflibrary {
 
    function __construct() {
		//FpdfLibrary
        include_once APPPATH . '/third_party/fpdf/fpdf.php';
    }
}
?>
